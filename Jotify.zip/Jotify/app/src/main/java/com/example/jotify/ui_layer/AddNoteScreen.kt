package com.example.jotify.ui_layer


import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Sort
import androidx.compose.material3.Button
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Alignment.Companion.CenterVertically
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.NavHostController


@Composable
fun AddNoteScreen(
    modifier: Modifier = Modifier,
    navController: NavController,
    state: NoteState,
    onEvent: (NoteEvent) -> Unit
) {

    Scaffold(
        topBar = {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .background(MaterialTheme.colorScheme.primary),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = "JOTIFY", color = Color.White,modifier = Modifier.weight(2f).padding(16.dp), fontSize = 25.sp, fontWeight = FontWeight.Bold)

            }
        }
    ) {

        Column(modifier = Modifier

            .fillMaxSize()
            .padding(it),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center

        ) {

            TextField(value = state.title.value, onValueChange = {
                state.title.value = it
            }, label = {
                Text("Title" )
            },
                placeholder = {
                    Text("Enter Title ")
                })

            Spacer(modifier = Modifier.height(20.dp))
            TextField(value = state.disp.value, onValueChange = {
                state.disp.value = it
            },
                label = { Text("Description") },
                placeholder = { Text("Enter Description") })
            Spacer(modifier = Modifier.height(30.dp))

            Button(
                onClick = {
                    onEvent(
                        NoteEvent.SaveNote(
                            title = state.title.value,
                            disp = state.disp.value
                        )
                    )
                    navController.popBackStack()
                },
            ) {
                Icon(imageVector = Icons.Rounded.Check, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.height(8.dp))
                Text("Save Note")
            }
        }
    }
}