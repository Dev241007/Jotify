package com.example.jotify.data_layer


import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Query
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

@Dao
interface NoteDao {
    @Upsert
    suspend  fun upsert(note: Note)

    @Delete
    suspend fun delete(note: Note)

    @Query("SELECT * FROM Note ORDER BY dataDated asc")
    fun getAllOrderedDateAdded(): Flow<List<Note>>

    @Query("SELECT * FROM Note ORDER BY title asc")
    fun getAllOrderedTitle(): Flow<List<Note>>
}